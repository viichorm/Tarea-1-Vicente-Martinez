#include "list.h"
#include <stdlib.h>

List *list_create() {
    List *list = (List *)malloc(sizeof(List));
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
    return list;
}

void list_pushBack(List *L, void *dato) {
    Node *new_node = (Node *)malloc(sizeof(Node));
    new_node->data = dato;
    new_node->next = NULL;
    if (L->tail == NULL) {
        L->head = new_node;
        L->tail = new_node;
    } else {
        L->tail->next = new_node;
        L->tail = new_node;
    }
    L->size++;
}

void *list_popFront(List *L) {
    if (L->size == 0) {
        return NULL;
    }
    Node *temp = L->head;
    void *data = temp->data;
    L->head = L->head->next;
    free(temp);
    L->size--;
    if (L->size == 0) {
        L->tail = NULL;
    }
    return data;
}

void list_clean(List *L) {
    while (L->size > 0) {
        list_popFront(L);
    }
    free(L);
}
