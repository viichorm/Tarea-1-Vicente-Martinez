#ifndef LIST_H
#define LIST_H

typedef struct Node {
    void *data;
    struct Node *next;
} Node;

typedef struct {
    Node *head;
    Node *tail;
    int size;
} List;

List *list_create();
void list_pushBack(List *L, void *dato);
void *list_popFront(List *L);
void list_clean(List *L);

#endif /* LIST_H */