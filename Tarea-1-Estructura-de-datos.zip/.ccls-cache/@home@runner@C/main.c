#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <time.h>
#include "tdas/queue.h"
#include "tdas/list.h"


typedef struct {

    char *name;
    int *edad;
    char *sintoma;
    char *prioridad;
    time_t horallegada;

} PersonaPaciente;


PersonaPaciente *ListaEspera = NULL;
int CantidadDePacientes = 0;



void Limpieza() {
    #ifdef _WIN32
        system("cls"); 
    #else
        system("clear");
    #endif
}

void CasoQueNoSeEncuentra(){
  Limpieza();
  printf("Opcion no valida. Por favor ingrese una opcion del 1 al 5.\n");
  sleep(5);
  Limpieza();
  
}


void MensajeHospitalario(){
  Limpieza();
  printf("................................................................\n");
  printf("Bienvenido a la aplicacion de gestion de pacientes del hospital\n");
  printf("................................................................\n\n");
  printf("1) Registre al paciente\n");
  printf("2) Asigne la prioridad a paciente\n");
  printf("3) Mostrar lista de espera\n");
  printf("4) Atender al siguiente paciente\n");
  printf("5) Mostrar Pacientes por Prioridad\n");
  printf("Escribe 'salir' para terminar la ejecución\n\n");
  printf("Seleccione alguna de las opciones\n");
}

void RegistrarPaciente(Queue *ListaEspera){
  printf("Se le solicitaran los siguentes datos del paciente: Nombre, Edad y sintoma\n");
  sleep(2);
  Limpieza();
  PersonaPaciente *nuevo_paciente = (PersonaPaciente *)malloc(sizeof(PersonaPaciente));
  nuevo_paciente->name = (char *)malloc(50 * sizeof(char));
  nuevo_paciente->sintoma = (char *)malloc(50 * sizeof(char));
  
  printf("Ingrese el nombre del paciente: \n");
  scanf("%s", nuevo_paciente->name);
  
  printf("Ingrese la edad del paciente: \n");
  scanf("%d", &(nuevo_paciente->edad));
  
  printf("Ingrese el sintoma del paciente \n");
  scanf("%s", nuevo_paciente->sintoma);
  
  nuevo_paciente->prioridad = "Bajo";
  nuevo_paciente->horallegada = time(NULL);
  
  queue_insert(ListaEspera, nuevo_paciente);
  
  printf("Paciente registrado con éxito.\n");
  sleep(4);
  while ((getchar()) != '\n');
}


void MostrarListaEspera(Queue *ListaEspera){

  printf("Lista de espera de pacientes:\n");
  Queue *tempQueue = queue_create();


  while (!queue_is_empty(ListaEspera)) {
    PersonaPaciente *paciente = (PersonaPaciente *)queue_remove(ListaEspera);
      printf("Nombre: %s, Edad: %d, Síntoma: %s, Prioridad: %s\n", paciente->name, *(paciente->edad), paciente->sintoma, paciente->prioridad);
    queue_insert(tempQueue, paciente);    
  }

  while (!queue_is_empty(tempQueue)) {
    queue_insert(ListaEspera, queue_remove(tempQueue));
  }
  queue_clean(tempQueue);
}

void AsignarPrioridadPaciente(Queue *ListaEspera){
    MostrarListaEspera(ListaEspera);
    
    int indice;
    printf("Ingrese el índice del paciente al que desea asignar la prioridad: ");
    scanf("%d", &indice);
    if (indice < 0 || indice >= queue_size(ListaEspera)) {
        printf("Índice inválido.\n");
        return;
    }

    PersonaPaciente *paciente = (PersonaPaciente *)queue_get_at(ListaEspera, indice);
    printf("Ingrese la prioridad para el paciente %s (Alto, Medio, Bajo): ", paciente->name);
    scanf("%s", paciente->prioridad);
    printf("Prioridad asignada correctamente.\n");
}



void AtenderSiguientePaciente(Queue *ListaEspera){


  
}


void MostrarPacientesPorPrioridad(Queue *ListaEspera){



  
}


int main(void) {
    char opcion[20];
    Queue *ListaEspera = queue_create();

    do {
        MensajeHospitalario();
        scanf("%s", opcion);
      for (int i = 0; opcion[i]; i++) {
          opcion[i] = tolower(opcion[i]);
      }

      char salir[] = "salir";
      for (int i = 0; salir[i]; i++) {
          salir[i] = tolower(salir[i]);
      }
      
        if (strcmp(opcion, "salir") == 0) {
            Limpieza();
            printf("Muchas gracias por usar el programa. Hasta luego.\n");
            sleep(4);
            break;
        }
        switch (opcion[0]) {
            case '1':
                Limpieza();
                RegistrarPaciente(ListaEspera);
                break;
            case '2':
                Limpieza();
                AsignarPrioridadPaciente(ListaEspera);
                break;
            case '3':
                Limpieza();
                MostrarListaEspera(ListaEspera);
                break;
            case '4':
                Limpieza();
                AtenderSiguientePaciente(ListaEspera);
                break;
            case '5':
                Limpieza();
                MostrarPacientesPorPrioridad(ListaEspera);
                break;
            default:
                CasoQueNoSeEncuentra();
                break;
        }
    } while (true);

    queue_clean(ListaEspera);
    return 0;
}