#include "queue.h"
#include <stdlib.h>

Queue *queue_create() {
    Queue *queue = (Queue *)malloc(sizeof(Queue));
    if (queue == NULL) {
        return NULL; // Error de asignación de memoria
    }
    queue->front = NULL;
    queue->rear = NULL;
    queue->size = 0;
    return queue;
}

void queue_insert(Queue *queue, void *data) {
    QueueNode *newNode = (QueueNode *)malloc(sizeof(QueueNode));
    if (newNode == NULL) {
        return; // Error de asignación de memoria
    }
    newNode->data = data;
    newNode->next = NULL;
    if (queue->rear == NULL) {
        queue->front = newNode;
    } else {
        queue->rear->next = newNode;
    }
    queue->rear = newNode;
    queue->size++;
}

void *queue_remove(Queue *queue) {
    if (queue->front == NULL) {
        return NULL; // La cola está vacía
    }
    QueueNode *temp = queue->front;
    void *data = temp->data;
    queue->front = queue->front->next;
    if (queue->front == NULL) {
        queue->rear = NULL;
    }
    free(temp);
    queue->size--;
    return data;
}

void *queue_front(Queue *queue) {
    return queue->front == NULL ? NULL : queue->front->data;
}

int queue_size(Queue *queue) {
    return queue->size;
}

bool queue_is_empty(Queue *queue) { // Implementación de la función
    return queue->front == NULL;
}

void queue_clean(Queue *queue) {
    while (queue->front != NULL) {
        QueueNode *temp = queue->front;
        queue->front = queue->front->next;
        free(temp);
    }
    queue->rear = NULL;
    queue->size = 0;
}


void *queue_get_at(Queue *queue, int index) {
    if (index < 0 || index >= queue->size) {
        return NULL; // Índice fuera de rango
    }

    QueueNode *current = queue->front;
    for (int i = 0; i < index; i++) {
        current = current->next;
    }

    return current->data;
}