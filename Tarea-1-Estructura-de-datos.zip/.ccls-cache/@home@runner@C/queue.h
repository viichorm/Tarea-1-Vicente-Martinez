#ifndef QUEUE_H
#define QUEUE_H

#include <stdbool.h> // Necesario para el tipo de dato bool

typedef struct QueueNode {
    void *data;
    struct QueueNode *next;
} QueueNode;

typedef struct {
    QueueNode *front;
    QueueNode *rear;
    int size;
} Queue;

Queue *queue_create();
void queue_insert(Queue *queue, void *data);
void *queue_remove(Queue *queue);
void *queue_front(Queue *queue);
int queue_size(Queue *queue);
bool queue_is_empty(Queue *queue);
void queue_clean(Queue *queue);
void *queue_get_at(Queue *queue, int index);

#endif /* QUEUE_H */