#include "tdas/list.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

typedef struct PersonaPaciente {
  char *name;
  int edad;
  char *sintoma;
  char *prioridad;
  time_t horallegada;
} PersonaPaciente;

typedef struct Nodo {
  PersonaPaciente *paciente;
  struct Nodo *next;
  struct Nodo *prev;
} Nodo;


List *lista;

int CantidadDePacientes = 0;

void SetTimeZone() {
  setenv("TZ", "America/Santiago", 1);
  tzset();
}

void Limpieza() {
#ifdef _WIN32
  system("cls");
#else
  system("clear");
#endif
}

void CasoQueNoSeEncuentra() {
  Limpieza();
  printf("Opcion no valida. Por favor ingrese una opcion del 1 al 5.\n");
  sleep(5);
  Limpieza();
}

void MensajeHospitalario() {
  Limpieza();
  printf("................................................................\n");
  printf("Bienvenido a la aplicacion de gestion de pacientes del hospital\n");
  printf(
      "................................................................\n\n");
  printf("1) Registre al paciente\n");
  printf("2) Asigne la prioridad a paciente\n");
  printf("3) Mostrar lista de espera\n");
  printf("4) Atender al siguiente paciente\n");
  printf("5) Mostrar Pacientes por Prioridad\n");
  printf("Escribe 'salir' para terminar la ejecución\n\n");
  printf("Seleccione alguna de las opciones\n");
}

void RegistrarPaciente(List *lista) {
  printf("Se le solicitaran los siguentes datos del paciente: Nombre, Edad y "
         "sintoma\n");
  sleep(2);
  Limpieza();

  PersonaPaciente *nuevo_paciente =
      (PersonaPaciente *)malloc(sizeof(PersonaPaciente));
  nuevo_paciente->name = (char *)malloc(50 * sizeof(char));
  nuevo_paciente->sintoma = (char *)malloc(50 * sizeof(char));

  printf("Ingrese el nombre del paciente: \n");
  scanf(" %[^\n]", nuevo_paciente->name);

  printf("Ingrese la edad del paciente: \n");
  while (scanf("%d", &nuevo_paciente->edad) != 1 || nuevo_paciente->edad < 0) {
    printf("Por favor ingrese una edad válida.\n");
    while (getchar() != '\n')
      ;
  }

  printf("Ingrese el sintoma del paciente \n");
  scanf(" %[^\n]", nuevo_paciente->sintoma);

  nuevo_paciente->prioridad = "Bajo";
  nuevo_paciente->horallegada = time(NULL);

  list_insert(lista, nuevo_paciente);

  printf("Paciente registrado con éxito.\n");
  sleep(4);
  while ((getchar()) != '\n')
    ;
}

void LiberarPaciente(PersonaPaciente *paciente) {
  free(paciente->name);
  free(paciente->sintoma);
  free(paciente);
}

void AsignarPrioridad(List *lista) {
  char nombre[50];
  char prioridad[10];
  printf("Lista de pacientes:\n");
  Nodo *nodo_actual = list_getHead(lista);
  while (nodo_actual != NULL) {
    printf("%s\n", nodo_actual->paciente->name);
    nodo_actual = list_getNext(nodo_actual);
  }
  printf("Ingrese el nombre del paciente: \n");
  scanf(" %49[^\n]", nombre);

  printf("Ingrese el nuevo nivel de prioridad (Alto, Medio, Bajo): \n");
  scanf(" %9s", prioridad);

  nodo_actual = list_getHead(lista);
  while (nodo_actual != NULL) {
    if (strcmp(nodo_actual->paciente->name, nombre) == 0) {
      list_sortedInsert(lista, nodo_actual->paciente, bcmp);
      list_remove(lista, nodo_actual->paciente);

      nodo_actual->paciente->prioridad = strdup(prioridad);
      if (nodo_actual->paciente->prioridad == NULL) {
        printf("Error al asignar prioridad.\n");
        return;
      }
      printf("Prioridad del paciente actualizada con éxito.\n");

      return;
    }
    nodo_actual = list_getNext(nodo_actual);
  }
  printf("Paciente no encontrado.\n");
}

void MostrarListaEspera(List *lista) {
  SetTimeZone();
  Nodo *nodo_actual = list_getHead(lista);
  if (nodo_actual == NULL) {
    printf("No hay pacientes en la lista de espera.\n");
    sleep(10);
    return;
  }

  while (nodo_actual != NULL) {
    printf("Nombre: %s\n", nodo_actual->paciente->name);
    printf("Edad: %d\n", nodo_actual->paciente->edad);
    printf("Sintoma: %s\n", nodo_actual->paciente->sintoma);
    printf("Prioridad: %s\n", nodo_actual->paciente->prioridad);

    time_t llegada = nodo_actual->paciente->horallegada - (4 * 3600);
    struct tm *local_time = localtime(&llegada);
    if (local_time == NULL) {
      perror("Error al obtener la hora local");
      return;
    }

    char time_str[100];
    strftime(time_str, sizeof(time_str), "%H:%M", local_time);
    printf("Hora de llegada : %s\n\n", time_str);

    nodo_actual = list_getNext(nodo_actual);
  }

  sleep(10);
}

void AtenderSiguientePaciente(List *lista) {
  if (list_getHead(lista) == NULL) {
    printf("No hay pacientes en espera.\n");
    sleep(5);
    return;
  }

  Nodo *paciente_atendido = list_getHead(lista);

  time_t hora_actual_utc;
  time(&hora_actual_utc);

  struct tm *hora_local = localtime(&hora_actual_utc);
  hora_local->tm_hour -= 4;
  mktime(hora_local);

  char hora_formateada[6];
  strftime(hora_formateada, sizeof(hora_formateada), "%H:%M", hora_local);

  printf("Paciente atendido:\n");
  printf("Nombre: %s\n", paciente_atendido->paciente->name);
  printf("Edad: %d\n", paciente_atendido->paciente->edad);
  printf("Sintoma: %s\n", paciente_atendido->paciente->sintoma);
  printf("Prioridad: %s\n", paciente_atendido->paciente->prioridad);
  printf("Hora de llegada: %s\n", hora_formateada);

  list_removeFront(lista);

  sleep(10);
}

void MostrarPacientesPorPrioridad(List *lista) {
  char prioridad[10];
  printf("Ingrese el nivel de prioridad (Alto, Medio, Bajo): \n");
  scanf("%9s", prioridad);

  SetTimeZone();

  Nodo *nodo_actual = list_getHead(lista);
  bool encontrado = false;
  while (nodo_actual != NULL) {
    if (strcmp(nodo_actual->paciente->prioridad, prioridad) == 0) {
      printf("Nombre: %s\n", nodo_actual->paciente->name);
      printf("Edad: %d\n", nodo_actual->paciente->edad);
      printf("Sintoma: %s\n", nodo_actual->paciente->sintoma);
      printf("Prioridad: %s\n", nodo_actual->paciente->prioridad);

      time_t llegada = nodo_actual->paciente->horallegada - (4 * 3600);
      struct tm *local_time = localtime(&llegada);
      if (local_time == NULL) {
        perror("Error al obtener la hora local");
        return;
      }

      char time_str[100];
      strftime(time_str, sizeof(time_str), "%H:%M", local_time);
      printf("Hora de llegada : %s\n\n", time_str);

      encontrado = true;
    }
    nodo_actual = list_getNext(nodo_actual);
  }
  if (!encontrado) {
    Limpieza();
    printf("No hay pacientes con esa prioridad.\n");
  }

  sleep(5);
}

int main(void) {
  char opcion[20];
  List *lista = list_create();

  do {
    MensajeHospitalario();
    scanf("%s", opcion);
    for (int i = 0; opcion[i]; i++) {
      opcion[i] = tolower(opcion[i]);
    }

    if (strcmp(opcion, "salir") == 0) {
      Limpieza();
      printf("Muchas gracias por usar el programa. Hasta luego.\n");
      sleep(4);
      break;
    }

    switch (opcion[0]) {
    case '1':
      Limpieza();
      RegistrarPaciente(lista);
      break;
    case '2':
      Limpieza();
      AsignarPrioridad(lista);
      printf("Función de asignar prioridad no implementada aún.\n");
      break;
    case '3':
      Limpieza();
      MostrarListaEspera(lista);
      printf("Función de mostrar lista de espera no implementada aún.\n");
      break;
    case '4':
      Limpieza();
      AtenderSiguientePaciente(lista);
      break;
    case '5':
      Limpieza();
      MostrarPacientesPorPrioridad(lista);
      printf(
          "Función de mostrar pacientes por prioridad no implementada aún.\n");
      break;
    default:
      CasoQueNoSeEncuentra();
      break;
    }
  } while (true);

  list_destroy(lista);

  return 0;
}
