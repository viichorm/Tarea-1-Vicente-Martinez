#include <stdlib.h>
#include <string.h>
#include "list.h"

List* list_create() {
    List* list = (List*)malloc(sizeof(List));
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
    return list;
}

void list_destroy(List* list) {
    Node* current = list->head;
    while (current != NULL) {
        Node* temp = current;
        current = current->next;
        free(temp);
    }
    free(list);
}

void list_insert(List* list, void* data) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = data;
    node->next = NULL;
    if (list->head == NULL) {
        list->head = node;
        list->tail = node;
    } else {
        node->prev = list->tail;
        list->tail->next = node;
        list->tail = node;
    }
    list->size++;
}

void* list_remove(List* list, int index) {
    if (index < 0 || index >= list->size) {
        return NULL;
    }
    Node* current = list->head;
    for (int i = 0; i < index - 1; i++) {
        current = current->next;
    }
    Node* temp = current->next;
    if (temp == list->tail) {
        list->tail = current;
    } else {
        current->next = temp->next;
        temp->next->prev = current;
    }
    void* data = temp->data;
    free(temp);
    list->size--;
    return data;
}

void* list_get(List* list, int index) {
    if (index < 0 || index >= list->size) {
        return NULL;
    }
    Node* current = list->head;
    for (int i = 0; i < index; i++) {
        current = current->next;
    }
    return current->data;
}

int list_size(List* list) {
    return list->size;
}


Node* list_getHead(List* list) {
    if (list == NULL || list->head == NULL) {
        return NULL; // Lista vacía o no inicializada
    }
    return list->head;
}


Node* list_getNext(Node* node) {
    if (node == NULL) {
        return NULL; // Nodo no inicializado
    }
    return node->next;
}


void list_removeFront(List *lista) {
    if (lista == NULL || lista->head == NULL) {
        return; // Lista vacía o no inicializada
    }

    Node *paciente_atendido = lista->head;
    lista->head = paciente_atendido->next;

    if (lista->head == NULL) {
        lista->tail = NULL;
    } else {
        lista->head->prev = NULL;
    }

    free(paciente_atendido);
}

void list_sortedInsert(List *list, void *data, int (*cmp)(void *, void *)) {
    Node *new_node = (Node *)malloc(sizeof(Node));
    new_node->data = data;
    new_node->next = NULL;
    new_node->prev = NULL;

    if (list->head == NULL) {
        list->head = new_node;
        list->tail = new_node;
        list->size++;
        return;
    }

    Node *current = list->head;
    Node *prev = NULL;

    while (current != NULL && cmp(data, current->data) > 0) {
        prev = current;
        current = current->next;
    }

    if (prev == NULL) {
        new_node->next = list->head;
        list->head->prev = new_node;
        list->head = new_node;
    } else if (current == NULL) {
        prev->next = new_node;
        new_node->prev = prev;
        list->tail = new_node;
    } else {
        prev->next = new_node;
        new_node->prev = prev;
        new_node->next = current;
        current->prev = new_node;
    }

    list->size++;
}
