#ifndef LIST_H
#define LIST_H

typedef struct Node Node;
typedef struct List List;

struct Node {
    void* data;
    Node* next;
    Node* prev;
};

struct List {
    Node* head;
    Node* tail;
    int size;
};

List* list_create();
void list_destroy(List* list);
void list_insert(List* list, void* data);
void* list_remove(List* list, int index);
void* list_get(List* list, int index);
int list_size(List* list);
Node* list_getHead(List* list);
void list_removeFront(List *lista);
void list_sortedInsert(List *list, void *data, int (*cmp)(void *, void *));

#endif  // LIST_H