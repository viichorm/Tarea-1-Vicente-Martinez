#include "node.h"
#include <stdlib.h>

// Aquí irían las implementaciones de las funciones que operan en los nodos.