#ifndef NODE_H
#define NODE_H

#include <time.h>

typedef struct PersonaPaciente {
    char *name;
    int edad;
    char *sintoma;
    char *prioridad;
    time_t horallegada;
} PersonaPaciente;

typedef struct Nodo {
    PersonaPaciente *paciente;
    struct Nodo *next;
    struct Nodo *prev;
} Nodo;



#endif // NODE_H
